class Employee {
    doWork() {
        return "Complete!"
    }
}

export default Employee