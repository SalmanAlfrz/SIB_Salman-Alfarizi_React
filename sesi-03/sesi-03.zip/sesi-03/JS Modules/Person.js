class Person {
    // constructor
    constructor (name) {
        this._name = name
    }
    getName() {
        return this._name
    }
}

export default Person