// #1
apaituVariable = 'Variable adalah sebuah wadah penyimpanan untuk data bisa berbentu angka atau kalimat ataupun status true dan false'
console.log(apaituVariable)

// #2
pentingnyaVariable = 'Pentingnya variable karena sebuah sistem ataupun program membutuhkan sebuah tempat untuk penyimpanan data yang dimana nantinya akan di olah'
console.log(pentingnyaVariable)

// #3
deklarasiVaribale = 'tipeData namaVariable'
console.log(deklarasiVaribale)

// #4
mengisiVariable = 'variable = "isi" / angka '
console.log(mengisiVariable)

// #5
apaitutipeData = 'Sebuah data memiliki tipenya masing-masing sesuai dengan kebutuhan'
console.log(apaitutipeData)

// #6
jenistipeData = 'String, Number, Boolean'
console.log(jenistipeData)

// #7
dataNumber = 'var dataNumber = 10; dataNumberNew = dataNumber + 10'
console.log(dataNumber)

// #8
dataString = 'var dataString = "Saya Salman"; var newdataString = "Halo " +dataString'
console.log(dataString)

// #9
dataBoolean = 'var dataBoolean = true'
console.log(dataBoolean)

// #10
mengetahuitipeData = 'menggunakan funtion dati javascript menggunakan typeof'
console.log(mengetahuitipeData)

// #11
apaituArrays = 'Array adalah sebuah wadah dimana bisa diisi dengan banyak data yang berderet nantinya'
console.log(apaituArrays)

// #12
jenisArrays = 'indexed array, multidimensional array, dan associative array'
console.log(jenisArrays)

// #13
mengisiArrays = 'menggunakan perintah push'
console.log(mengisiArrays)