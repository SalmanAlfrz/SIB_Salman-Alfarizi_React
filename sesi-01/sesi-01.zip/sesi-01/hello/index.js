//variable var
var angka = 50
angka = 10
console.log(angka)

//variable const
let score = 50
console.log("Hasil "+score)

let playerName = "Budi"
console.log("Hasil "+playerName)
playerName = "Andi"
console.log("Player 2 "+playerName)

//variable konstanta
const objectAngka = {id:1, name:'Arif', jenKel:'1'}
objectAngka.id = 2
objectAngka.name = 'Salman'
objectAngka.jenKel = 'Laki-laki'
console.log(objectAngka)

const arrayAngka = [1,2,3,4,5]
arrayAngka.push(6)
arrayAngka.push(7)
console.log(arrayAngka)